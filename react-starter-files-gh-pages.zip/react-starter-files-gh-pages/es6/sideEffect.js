(function (global) {
  global.$ = '我是 jQuery';
})(window);