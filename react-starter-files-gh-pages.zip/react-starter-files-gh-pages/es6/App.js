
const App = () => {
  const myName = '卡斯伯'
  return React.createElement('div', null, `我的名字是 ${myName}`);
}

export default App;