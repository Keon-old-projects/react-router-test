export const a = 1;

export function b() {
  console.log('1');
}

export function c(a, b) {
  return a + b;
}